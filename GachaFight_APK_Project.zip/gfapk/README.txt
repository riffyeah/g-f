GACHA & FIGHT — Android offline WebView project

This project packages the latest HTML in app/src/main/assets/index.html and opens it locally in an Android WebView. Local game logic and localStorage are available offline.

Important:
- Online leaderboard/global chat require internet and the existing Supabase service.
- The HTML references Google Fonts and Supabase from external URLs. The game can still load the bundled HTML offline, but those online resources/features will be unavailable without internet. For a fully self-contained build, remove external font dependencies or bundle font files locally.
- No compiled APK is included because this environment has no Android SDK/Gradle installation.

Build APK with Android Studio:
1. Open this folder as an existing Gradle project.
2. Install Android SDK Platform 35 and a compatible JDK if prompted.
3. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Android Studio will show the APK output location.

Application ID: com.riff.gachafight
Minimum Android: 6.0 (API 23)
Default orientation: landscape

BUILD APK FROM PHONE WITH GITHUB ACTIONS
1. Create a new GitHub repository.
2. Upload the CONTENTS of this gfapk folder to the repository root, including the hidden .github folder.
3. Open the repository's Actions tab and select 'Build GACHA & FIGHT APK'.
4. If it shows a Run workflow button, tap it and confirm Run workflow.
5. Open the completed run, find Artifacts, and download GACHA-FIGHT-APK.
6. Extract the downloaded artifact ZIP to get app-debug.apk, then install it on Android.

The workflow builds a debug APK. This project is primarily offline; online features may not work as configured.
